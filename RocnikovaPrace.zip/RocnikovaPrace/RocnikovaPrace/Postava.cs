﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RocnikovaPrace
{
    internal class Postava
    {
        public string Name { get; set; }
        public int MaxHeart { get; set; }
        public int Heart { get; set; }
        public int MaxJuice { get; set; }
        public int Juice { get; set; }
        public int Attack { get; set; }
        public int Defense { get; set; }
        public int Speed { get; set; }
        public int Luck { get; set; }
        public int Hit { get; set; }
    }
}
